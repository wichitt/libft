/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wamonvor <wamonvor@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/18 14:21:14 by wamonvor          #+#    #+#             */
/*   Updated: 2023/03/20 15:45:32 by wamonvor         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_atoi(const char *s)
{
	int	i;
	int	sign;
	int	num;

	i = 0;
	sign = 1;
	num = 0;
	while (s[i] == 32 || (s[i] >= 9 && s[i] <= 13))
		i++;
	if (s[i] == 45 || s[i] == 43)
	{
		if (s[i] == 45)
			sign *= -1;
		i++;
	}
	while (s[i] >= 48 && s[i] <= 57)
	{
		num = num * 10 + (s[i] - 48);
		i++;
	}
	return (num * sign);
}

 /*
 * 32 is space 
 * 9 to 13 is control characters 
 * 45 or 43 is - + 
 * 48 to 57 is 0 - 9
 * this function : which converts a string representation 
 * of an integer into an integer value
 * how it work ?
 * check control characters until met (+ , -)
 * and then move make int valus by whil loop 
 * until end of string data
 * Value of INT_MAX is +2147483647.
 * Value of INT_MIN is -2147483648.
    when values more than max int it will be return opposite value 
	sample -2147483649 ---> +2147483647
	-2147483650 ---> +2147483626

2147483648 --> -2147483648
2147483649 --> -2147483647
4294967296 = 0 4294967297 = 1 

 */