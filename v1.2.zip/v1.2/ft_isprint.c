/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isprint.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wamonvor <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/18 14:22:25 by wamonvor          #+#    #+#             */
/*   Updated: 2023/02/18 14:22:26 by wamonvor         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_isprint(int c)
{
	return (c >= 32 && c <= 127);
}
/*
this function is checks character is a printable character.
how it works
print abel character is start from 32 - 127 
(c >= 32 && c <= 127) 
|---> if c between 32-127 function will be return 0 
C, expressions that evaluate to a non-zero value are considered true. 
in case c == 32  return (c >= 32 && c <= 127); --> return 1 (true);
in case c < 32 or > 127 --> return 0 (false) ;
*/